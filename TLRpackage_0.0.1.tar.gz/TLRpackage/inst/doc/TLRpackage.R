## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(TLRpackage)
library(data.table)
library(ggplot2)

## ----1------------------------------------------------------------------------
data <- TL_read("hdro_indicators_irl.csv")
class(data)
class(data$'year')
class(data$'country_code')

## ----2------------------------------------------------------------------------
data <- TL_print(data)

